# 数据字典

所有ID为本地随机标识；时间为ISO 8601 UTC、来源是设备时钟。数据表通过ID关联。

- study_id：研究容器标识；不是注册号。
- artifact_id / parent_id：不可覆盖方案版本及父版本。
- origin_run_id：该方案由哪次运行的人工审阅产生。
- evidence_event_ids / selected_event_ids：被选作参考的事件；来源仍须检查。
- run_id / input_snapshot / settings_snapshot：测试及当时的方案、配置快照。
- condition：single_model、multi_agent、multi_agent_human；仅拟定条件。
- execution_mode：本原型固定manual_and_scripted_demo。
- source：demo / human_input / manual_observation。
- data_provenance：synthetic_script / human_in_simulation / manual_unverified。
- actor_type：scripted_agent或human；不会冒称真实模型输出。
- sequence：同一run内递增序号；reply_to是同一run内父消息。
- kind：assertion/question/critique/response/revision/observation。
- has_human_intervention：有真人消息即为true，结束后保持。
- model_calls：本原型为0。温度、随机种子留空表示未配置。
- verdict：supported/unsupported/uncertain/not_assessed；都是人工评价。
- score：0至4的可实施性人工评分，null或空列为缺失；描述见ratings.csv。
- independence：not_verified，不主张评价者独立性。
- context_policy：只将确认方案作为下一环节输入，事件保留为可查引用。
- audit：本地操作日志，非不可篡改审计。

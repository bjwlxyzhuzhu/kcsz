# 过程数据字段说明

| 字段 | 含义与边界 |
|---|---|
| started_at / ended_at | 本地设备时间，UTC ISO 格式 |
| duration_ms | 完成运行的墙钟时间，包含暂停；运行中为空 |
| elapsed_ms | 事件距开始经过的毫秒数 |
| interval_from_prev_ms | 同运行相邻事件间隔，不是思考时间 |
| response_latency_ms | 回复与 reply_to 事件的时间差 |
| input_duration_ms | 打开发言框至提交的停留时间，不是主动学习时间 |
| reply_to / target_actor | 被回复事件与目标身份；未指定时为空 |
| interaction_mode / group_id / task_role | 冻结运行模式、发言组别、当前任务分工 |
| data_provenance | 脚本、真人模拟输入或未经验证观察 |
| rubric_scores | 七维人工0—4等级，未评分为空 |
| source_artifact_id / target_artifact_id | 模块流转前后的方案版本ID |

真实学生学习时长、离屏停留、认知投入、语音时长、前测/后测与延迟保持均未测量。模型调用数为0。历史记录未采集的新增字段保持缺失，不能倒填。
